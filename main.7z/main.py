import itertools

question_list = []
option_list = []
correct_answer = []


def main_content():
    score = 0
    main = '1. Add question \n2. Show question \n3. quiz \n4. Exit'
    print(main)


    a = input('enter the value:')
    int_a = int(a)


    if a == '1':
            b = int(input('How many questions you want:'))
            for x in range(b):
                question_list.append(input('Enter your question:'))
                o = input('Option A:')
                p = input('Option B:')
                m = input('Option C:')
                r = input('Option D:')
                q = 'A):{}\nB):{}\nC):{}\nD):{}\nPut your answer here:'.format(o, p, m, r)
                option_list.append(q)
                correct_answer.append(input('Put your answer here:'))
            main_content()
    if a == '2':
        if len(question_list) == 0:
            print('There are no question')
        else:
            for question, choices, answers in zip(question_list, option_list, correct_answer):
                print(question)
            main_content()
    if a == '3':
        if len(question_list) == 0:
            print('There are no question')
        else:
            for question, choices, correct_choice in zip(question_list, option_list, correct_answer):
                print(question)
                user_answer = input(choices).lower()
                if user_answer == correct_choice:
                    print("Correct")
                    score += 1
                    print(score, "out of", len(question_list),"that is", float(score / len(question_list)) * 100, "%")
                else:
                    print('False Answer')
                    print('Your score is', score, "out of", len(question_list), "that is", float(score / len(question_list)) * 100, "%")
            main_content()
    if a == '4':
        exit()





































#uestions = []
#options = []
#def main_content():
#    main = '1. Add question \n2. Show question \n3. quiz \n4. Exit'
#    print(main)

#    a = input('enter the value:')




 #   if a == '1':
 #       b = input("How many questions you want :")
 #       int_b = int(b)

 #   for x in range(int_b):
 #       questions.append(input('Enter your question:'))
 #       options.append(input('Option A:'))
 #       options.append(input('Option B:'))
 #       options.append(input('Option C:'))
 #       options.append(input('Option D:'))p
 #       print(questions)
 #       print(options)
 #       print(main)
 #       l = input('input the value:')


main_content()
