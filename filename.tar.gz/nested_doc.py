

nested_dictionary = {
    "id": "1",
    "name": "IT DEPART",
    "team": [

          {
        "id": "1",
        "name": "web",
        "package": [
          {
            "package_name": "codeDog_git",
            "package_url": "https://github.com/mickymous1/CodeDog.git"
          },
          {
            "package_name": "codeDog_zip",
            "package_url": "https://github.com/mickymous1/CodeDog/archive/refs/heads/master.zip"
          },
          {
            "package_name": "3dchess_apt",
            "package_url": "apt-get install 3dchess"
          },
          {
            "package_name": "packageBDF",
            "package_url": ""
          },
          {
            "package_name": "packageXYZ",
            "package_url": "Package_url packageXYZ"
          }
        ]
      },
        {
            "id": "2",
            "name": "Mobile",
            "package": [
                {
                    "package_name": "tarball",
                    "package_url": "https://github.com/phayes/geoPHP/tarball/master"
                },
                {
                    "package_name": "",
                    "package_url": "Mobile packageZZZZZ"
                },
                {
                    "package_name": "packageSADJKSA",
                    "package_url": "Mobile packageSADJKSA"
                },
                {
                    "package_name": "packageBDF",
                    "package_url": "Mobile packageSADJKSA"
                },
                {
                    "package_name": "packageXYZ",
                    "package_url": "Mobile packageXYZ"
                }
            ]
    },
        {
            "id": "2",
            "name": "Mobile",
            "package": [
                {
                    "package_name": "packageUIEUIREIRJ",
                    "package_url": "Mobile packageUIEUIREIRJ"
                },
                {
                    "package_name": "packageZZZZZ",
                    "package_url": "Mobile packageZZZZZ"
                },
                {
                    "package_name": "packageSADJKSA",
                    "package_url": "Mobile packageSADJKSA"
                },
                {
                    "package_name": "packageBDF",
                    "package_url": "Mobile packageSADJKSA"
                },
                {
                    "package_name": "packageXYZ",
                    "package_url": "Car packageXYZ"
                }
            ]
        }

    ]
  }



for p in [item for x in nested_dictionary['team'] for item in x['package']]:
    print(p['package_name'] + ' : ' + p['package_url'])


#for p in nested_dictionary['team'][0]['package']:
#    for i in nested_dictionary['team'][1]['package']:
#        print(p)
#        print(i)



# name = p['package_name']
# print(name + ' : ' + p['package_url'])

#for i in nested_dictionary['team'][1]['package']:
#    name_mobile = i['package_name']
#    print(name_mobile + ' : ' + p['package_url'])

#for p in nested_dictionary['team']:

#    print(p['package'])
